import React from 'react';

export default function Product(prop) {
  return (
    <div className="product">
      <img src={prop.src} alt={prop.name + 'picture'} className="prodPic" />
      <p className="name">{prop.name + ' Apartment'}</p>
      <p className="price">{'$' + prop.price}</p>
    </div>
  );
}
