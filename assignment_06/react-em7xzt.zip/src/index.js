import React from 'react';
import { createRoot } from 'react-dom/client';
import Product from './Product.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div className="header">
      <h1>Apartment Shopper</h1>
    </div>
    <div className="prodBox">
      <Product
        src="https://www.aiany.org/wp-content/uploads/2019/08/New-York-City_Jorge-Lascar-1280x850.jpg"
        name="New York"
        price="3450"
      />
      <Product
        src="https://pix4free.org/assets/library/2021-01-12/originals/los_angeles_california_cityscape_downtown_offices.jpg"
        name="Los Angeles"
        price="1432"
      />
      <Product
        src="https://www.travelandleisure.com/thmb/xsZOdFFzSrZ2tEs0u6Rr-bN10Oo=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/houston-texas-HTXTG0221-7e22cd4db19f46d7820fa124e25d4d75.jpg"
        name="Houston"
        price="1145"
      />
      <Product
        src="https://upload.wikimedia.org/wikipedia/commons/b/b7/Chicago_cityscape_%285253757001%29.jpg"
        name="Chicago"
        price="2309"
      />
    </div>
    <div className="footer">
      <p>Appartment Shopper&copy;</p>
    </div>
  </React.StrictMode>
);
