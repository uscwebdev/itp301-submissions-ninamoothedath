import React from 'react';

export default function Post(prop) {
  return (
    <div className="commentBox">
      <div>
        <img
          src={prop.src}
          alt={prop.user + 'Profile Picture'}
          className="profile"
        />
        <p className="user">{prop.user}</p>
        <p className="date">{prop.date}</p>
      </div>
      <div>
        <p class="post">{prop.text}</p>
      </div>
    </div>
  );
}
