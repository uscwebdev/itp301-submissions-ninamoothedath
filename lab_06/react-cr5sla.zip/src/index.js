import React from 'react';
import { createRoot } from 'react-dom/client';
import Post from './Post.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div className="header">
      <h1>- Journalize -</h1>
    </div>

    <div className="text">
      <p>
        Welcome to Jouranlize, the collaborative jouranling platform you've been
        waiting for. Visit every day for a journaling prompt for you to complete
      </p>
      <p>
        It's your choice whether you want to journal your answers in a physical
        journal, privatley within your digital Journalize journal, or to your
        public Journalize page!
      </p>
      <p>
        You can find today's journaling music of the day{' '}
        <a href="https://www.youtube.com/watch?v=ZZUD25bZBI8">at this link</a>{' '}
        while you check out some of the responses to today's prompt, "What
        lifted your mood today?":
      </p>
    </div>

    <div className="imgBox">
      <img
        src="https://images.unsplash.com/photo-1604933762161-67313106146c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2940&q=80"
        alt="a person typing"
      />
      <img
        src="https://images.unsplash.com/photo-1488190211105-8b0e65b80b4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2940&q=80"
        alt="a person writing in a journal, birds eye view"
      />
    </div>

    <div className="responses">
      <Post
        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3aDHlzgAfDG4_gGi4P2MKfwY-dqaqLwH-kPuyfU240-BZd32D5NsX_NSbdj6l1gg0OQU&usqp=CAU"
        user="User20021"
        date="9/8/2023"
        text="Today I had one of my favorite foods! It was so comforting and I'm
        really glad I had it!"
      />
      <Post
        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRN0pHtVBVeyi8OjaGf1tw1IY8ctQfkAedvt8cIZb5kEQtxmp-jtxFrDp0jGETAeohYn5k&usqp=CAU"
        user="Janet_Rose"
        date="9/8/2023"
        text="I was in the store and heard a song I really like playing! It made me smile."
      />
      <Post
        src="https://www.shareicon.net/download/2016/07/05/791210_people_512x512.png"
        user="someone_out_there"
        date="9/8/2023"
        text="Someone told me that they thought my outfit looked nice! That was so
            thoughtful!"
      />
      <Post
        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQdmeorIX1HKs5B0zaHEY3jhJyThhGEnh9mocasKLlNVGBG00ZoX6KWK4EHAOXI37uxScc&usqp=CAU"
        user="GreenGarnet"
        date="9/8/2023"
        text="I went to see a movie with some friends and it was super fun! We got
            boba afterwards :)"
      />
    </div>
  </React.StrictMode>
);
