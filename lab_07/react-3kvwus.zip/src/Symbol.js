import React from 'react';
import { useState } from 'react';

export default function Symbol() {
  const [src, setSrc] = useState(
    'https://upload.wikimedia.org/wikipedia/commons/4/43/3x3_basketball_pictogram.svg'
  );

  const [alt, setAlt] = useState('3x3 Basketball symbol');

  const [caption, setCaption] = useState('3x3 Basketball');

  function buttonPress(newSrc, newAlt, newCaption) {
    setSrc(newSrc);
    setAlt(newAlt);
    setCaption(newCaption);
  }

  return (
    <div className="main">
      <div className="header">
        <h1>The Newest Games at the Summer Olympics</h1>
      </div>
      <div className="imgBox">
        <img id="image" src={src} alt={alt} />
      </div>
      <p>{caption}</p>
      <div className="buttonBox">
        <button
          onClick={() => {
            buttonPress(
              'https://upload.wikimedia.org/wikipedia/commons/4/43/3x3_basketball_pictogram.svg',
              '3x3 Basketball symbol',
              '3x3 Basketball'
            );
          }}
        >
          3x3 basketball
        </button>
        <button
          onClick={() => {
            buttonPress(
              'https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/Breakdancing_pictogram.svg/1200px-Breakdancing_pictogram.svg.png',
              'Breaking symbol',
              'Breaking'
            );
          }}
        >
          Breaking
        </button>
        <button
          onClick={() => {
            buttonPress(
              'https://upload.wikimedia.org/wikipedia/commons/thumb/3/37/Skateboarding_pictogram.svg/1200px-Skateboarding_pictogram.svg.png',
              'Skateboarding symbol',
              'Skateboarding'
            );
          }}
        >
          Skateboarding
        </button>
        <button
          onClick={() => {
            buttonPress(
              'https://upload.wikimedia.org/wikipedia/commons/f/fa/Surfing_pictogram.svg',
              'Surfing symbol',
              'Surfing'
            );
          }}
        >
          Surfing
        </button>
        <button
          onClick={() => {
            buttonPress(
              'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Taekwondo_pictogram.svg/1200px-Taekwondo_pictogram.svg.png',
              'Taekwondo symbol',
              'Taekwondo'
            );
          }}
        >
          Taekwondo
        </button>
      </div>
    </div>
  );
}
