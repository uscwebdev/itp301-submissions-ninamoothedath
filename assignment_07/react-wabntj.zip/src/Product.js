import React from 'react';
import { useState } from 'react';

export default function Product(prop) {
  const [count, setCount] = useState(0);

  function handleMinusClick() {
    if (count == 0) {
      console.log('0');
    } else {
      setCount(count - 1);
    }
  }

  function handlePlusClick() {
    setCount(count + 1);
  }

  return (
    <div className="product">
      <img src={prop.src} alt={prop.name + 'picture'} className="prodPic" />
      <p className="name">{prop.name + ' Apartment'}</p>
      <p className="price">{'$' + prop.price}</p>
      <div className="buttons">
        <button
          onClick={() => {
            handleMinusClick();
          }}
        >
          -
        </button>
        <p id="counter">{count}</p>
        <button
          onClick={() => {
            handlePlusClick();
          }}
        >
          +
        </button>
      </div>
    </div>
  );
}
