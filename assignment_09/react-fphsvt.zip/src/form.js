import React from 'react';
import { useState } from 'react';

export default function Form() {
  const [fName, setFName] = useState('');
  const [prefix, setPrefix] = useState(false);
  const [suffix, setSuffix] = useState(false);
  const [middle, setMiddle] = useState(false);
  const [prefixField, setPrefixField] = useState('');
  const [suffixField, setSuffixField] = useState('');
  const [mName, setMName] = useState('');
  const [lName, setLname] = useState('');
  const [email, setEmail] = useState('');
  const [zip, setZip] = useState('');
  const [city, setCity] = useState('Los Angeles');
  const [check, setCheck] = useState(false);

  const [fNameError, setNameFError] = useState();
  const [lNameError, setLNameError] = useState();
  const [prefixError, setPrefixError] = useState();
  const [suffixError, setSuffixError] = useState();
  const [mNameError, setNameMError] = useState();
  const [emailError, setEmailError] = useState();
  const [zipError, setZipError] = useState();

  return (
    <form submit="">
      <div>
        <label htmlFor="first-name">First Name: </label>
        <input type="text" id="first-name" value={fName} />
        <p>{fNameError}</p>
      </div>

      <div>
        <label htmlFor="last-name">Last Name: </label>
        <input type="text" id="last-Name" value={lName} />
        <p className="red">{lNameError}</p>
      </div>

      <div>
        <p>Check to show additional name options:</p>
        <input type="checkbox" id="prefix" value={prefix} />
        <label htmlFor="prefix">Prefix</label>
        <input type="checkbox" id="suffix" value={suffix} />
        <label htmlFor="suffix">Suffix</label>
        <input type="checkbox" id="middle" value={middle} />
        <label htmlFor="middle">Middle Name</label>
      </div>

      <div>
        <label htmlFor="prefix-field">Prefix: </label>
        <input type="text" id="prefix-field" value={prefixField} />
        <p className="red">{prefixError}</p>
      </div>

      <div>
        <label htmlFor="suffix-field">Suffix: </label>
        <input type="text" id="suffix-field" value={suffixField} />
        <p className="red">{suffixError}</p>
      </div>

      <div>
        <label htmlFor="middle-name">Middle Name:</label>
        <input type="text" id="middle-name" value={mName} />
        <p className="red">{mNameError}</p>
      </div>

      <div>
        <label htmlFor="email">Email: </label>
        <input type="text" id="email" value={email} />
        <p className="red">{emailError}</p>
      </div>
      <div>
        <label htmlFor="zip">Zip Code: </label>
        <input type="text" value={zip} />
        <p className="red">{zipError}</p>
      </div>

      <div>
        <button>Verify Details</button>
      </div>
      {/* When the button is clicked the errors are checked and then the city for the next part comes from an API based on the zip code that was entered*/}
      <div>
        <label htmlFor="city">
          The zip code you entered is in {city}. Check the box if this is
          correct.
        </label>
        <input type="checkbox" id="city" value={check} />
      </div>
      <div>
        <button>Submit</button>
      </div>
    </form>
  );
}
