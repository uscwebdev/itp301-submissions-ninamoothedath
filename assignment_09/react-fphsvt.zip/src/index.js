import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import $ from 'jquery';
import Book from './book.js';
import Generator from './generator.js';
import Form from './form.js';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div className="header"></div>
    <div className="main1">
      <h1>
        Books <span className="red">Banned</span> Behind Bars
      </h1>
      <p>
        Book bans have taken affect across history as governments, schools and
        libraries enforce rules to limit what readers can access. Within the US,
        prisons are one of these entities. Depending on state law, some don't
        have to give a reason for a book to be banned, and some of the ones that
        are might suprise you.
      </p>
      <p>
        Explore banned books below using the generator. Click the refresh button
        to generate a new random banned book and the reason why it was banned,
        and use the plus button if you'd like to add them to a reading list you
        can have emailed to you when you're ready.
      </p>
      <Generator />
      <a href="#main2">
        <img
          className="down"
          src="https://cdn.iconscout.com/icon/free/png-256/free-down-arrow-1767499-1502567.png"
          alt="down arrow"
        />
      </a>
    </div>

    <div id="main2">
      <h2>Your list</h2>
      <p>Edit your list below:</p>
      <div className="list">
        <Book />
        <Book />
        <Book />
        <Book />
        <Book />
        <Book />
      </div>
      <a href="#main3">
        <img
          className="down"
          src="https://cdn.iconscout.com/icon/free/png-256/free-down-arrow-1767499-1502567.png"
          alt="down arrow"
        />
      </a>
    </div>

    <div id="main3">
      <p>
        Enter your details to have your list sent to your email and to enter a
        giveway to have up to 10 of the books on your list sent to you free of
        charge!
      </p>
      <Form />
    </div>
    <div className="bar"></div>
  </React.StrictMode>
);
