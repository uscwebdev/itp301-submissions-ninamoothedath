import React from 'react';
import { useState } from 'react';
import $ from 'jquery';

export default function Generator() {
  const [title, setTitle] = useState('Homesteading');
  const [author, setAuthor] = useState('Abigail Gehring');
  const [ban, setBan] = useState(
    'Reason banned: DOC 309.05 (2)(b)(4) how to make alcohol'
  );
  const [result, setResult] = useState([]);

  function newBook() {
    console.log('clicked!');
  }

  return (
    <div className="box">
      <div>
        <img
          src="https://m.media-amazon.com/images/I/51uvhT-uqbL.jpg"
          alt={title + 'cover'}
        />
      </div>
      <div className="boxinfo">
        <p className="bTitle">{title}</p>
        <p className="author">{author}</p>
        <p className="ban">{ban}</p>
        <div className="iconbox">
          <div className="plus">
            <img
              src="https://cdn.iconscout.com/icon/free/png-256/free-plus-89-433616.png"
              alt="add button"
            />
          </div>
          <div className="refresh">
            <img
              onClick={newBook}
              src="https://cdn.iconscout.com/icon/free/png-256/free-refresh-454-450611.png"
              alt="refresh button"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
