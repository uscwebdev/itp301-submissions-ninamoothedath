import React from 'react';
import { useState } from 'react';
import $ from 'jquery';

export default function Book() {
  return (
    <div>
      <img
        className="bookCover"
        src="https://m.media-amazon.com/images/I/51uvhT-uqbL.jpg"
        alt="bookcover"
      />
      <p>
        Description LOREM IPSUM Description LOREM IPSUM Description LOREM IPSUM
        Description LOREM IPSUM Description LOREM IPSUM Description LOREM IPSUM
        Description LOREM IPSUM Description LOREM IPSUM Description LOREM IPSUM{' '}
      </p>
      <button className="remove">Remove</button>
    </div>
  );
}
