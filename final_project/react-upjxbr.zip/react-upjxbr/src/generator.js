import React from 'react';
import { useState } from 'react';
import $ from 'jquery';

export default function Generator() {
  const [name, setName] = useState('John Doe');
  const [username, setUsername] = useState('John Doe');
  const [password, setPassword] = useState('byxcjwaocAcd_7qhg5');
  const [email, setEmail] = useState('example@gmail.com');
  const [src, setSrc] = useState('https://picsum.photos/id/20/200');
  const [fun, setFun] = useState('A snail can sleep for three years.');
  const [result, setResult] = useState([]);

  function newInfo() {
    $.ajax({
      url: 'https://randomuser.me/api/',
      dataType: 'json',
      success: function (data) {
        console.log(data.results[0]);
        setName(data.results[0].name.first + data.results[0].name.last);
        setEmail(data.results[0].email);
        setUsername(data.results[0].login.username);
      },
    });
    $.ajax({
      url: 'https://uselessfacts.jsph.pl/api/v2/facts/random',
      dataType: 'json',
      success: function (data) {
        console.log(data.text);
        setFun(data.text);
      },
    });
    document.querySelector('.refresh img').style.opacity = '1';
  }

  function newUser(e) {
    e.preventDefault();
    console.log('clicked!');
    document.querySelector('.refresh img').style.opacity = '0.5';
    setPassword('');
    setName('Loading, please wait...');
    setEmail('');
    setUsername('');
    setFun('');
    $.ajax({
      url: 'https://passwordinator.onrender.com?num=true&char=true&caps=true&len=18',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        setPassword(data.data);
        console.log('newbook!');
        setSrc('');
        let random = Math.floor(Math.random() * 300 + 1);
        setSrc('https://picsum.photos/id/' + random + '/200');
        newInfo();
      },
      error: function (error) {
        console.log(error);
        alert(error);
      },
    });
  }

  return (
    <div className="box">
      <div>
        <img src={src} alt={'cover'} />
      </div>
      <div className="boxinfo">
        <p>{'Name: ' + name}</p>
        <p>{'Username: ' + username}</p>
        <p>{'Password: ' + password}</p>
        <p>{'Email: ' + email}</p>
        <p>{'Fun fact for bio: ' + fun}</p>
      </div>
      <div className="iconbox">
        <div className="refresh">
          <img
            onClick={newUser}
            src="https://cdn.iconscout.com/icon/free/png-256/free-refresh-454-450611.png"
            alt="refresh button"
          />
        </div>
      </div>
    </div>
  );
}
