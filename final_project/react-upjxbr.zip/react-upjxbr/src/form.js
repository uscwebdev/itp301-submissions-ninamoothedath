import React from 'react';
import { useState } from 'react';
import $ from 'jquery';

export default function Form() {
  const [fName, setFName] = useState('');
  const [prefix, setPrefix] = useState(true);
  const [suffix, setSuffix] = useState(true);
  const [middle, setMiddle] = useState(true);
  const [prefixField, setPrefixField] = useState('');
  const [suffixField, setSuffixField] = useState('');
  const [mName, setMName] = useState('');
  const [lName, setLname] = useState('');
  const [email, setEmail] = useState('');
  const [zip, setZip] = useState('');
  const [city, setCity] = useState('');
  const [check, setCheck] = useState(false);

  const [fNameError, setNameFError] = useState();
  const [lNameError, setLNameError] = useState();
  const [prefixError, setPrefixError] = useState();
  const [suffixError, setSuffixError] = useState();
  const [mNameError, setNameMError] = useState();
  const [emailError, setEmailError] = useState();
  const [zipError, setZipError] = useState();
  const [checkError, setCheckError] = useState();

  function handleChange(e) {
    var id = e.currentTarget.id;
    if (id == 'first-name') {
      setFName(e.currentTarget.value);
    } else if (id == 'last-Name') {
      setLname(e.currentTarget.value);
    } else if (id == 'prefix-field') {
      setPrefixField(e.currentTarget.value);
    } else if (id == 'suffix-field') {
      setSuffixField(e.currentTarget.value);
    } else if (id == 'middle-name') {
      setMName(e.currentTarget.value);
    } else if (id == 'email') {
      setEmail(e.currentTarget.value);
    } else if (id == 'zip') {
      setZip(e.currentTarget.value);
    } else if (id == 'check') {
      setCheck(!check);
    }
  }

  function handleOptionChange(e) {
    var id = e.currentTarget.id;
    if (id == 'prefix') {
      setPrefix(!prefix);
      if (prefix == true) {
        document.querySelector('.prefix-box').style.display = 'block';
      } else {
        document.querySelector('.prefix-box').style.display = 'none';
      }
    } else if (id == 'suffix') {
      setSuffix(!suffix);
      if (suffix == true) {
        document.querySelector('.suffix-box').style.display = 'block';
      } else {
        document.querySelector('.suffix-box').style.display = 'none';
      }
    } else if (id == 'middle') {
      setMiddle(!middle);
      console.log(middle);
      if (middle == true) {
        document.querySelector('.middle-box').style.display = 'block';
      } else {
        document.querySelector('.middle-box').style.display = 'none';
      }
    }
  }

  function verify(e) {
    e.preventDefault();
    console.log('clicked');
    var searchUrl =
      ' https://api.zipcodestack.com/v1/search?codes=' +
      String(zip) +
      '&country=us' +
      '&apikey=01HGCVVH8099SR8G0PTC7K1RVV';
    if (zip.length == 5 && !isNaN(zip)) {
      document.querySelector('.hide').style.display = 'block';
      setZipError('');
      $.ajax({
        url: searchUrl,
        dataType: 'json',
        success: function (data) {
          setCity(data.results[zip][0].city);
        },
        error: function (error) {
          console.log(error);
        },
      });
    } else {
      setZipError('Please enter a valid, 5-digit zip code');
    }
  }

  function handleSubmit(e) {
    var foundError = false;
    e.preventDefault();
    if (fName.length == 0) {
      foundError = true;
      setNameFError('Please enter your first name');
    } else if (fName[0].toLowerCase() == fName[0]) {
      foundError = true;
      setNameFError('Please capitalize your name');
    } else {
      setNameFError('');
    }

    if (lName.length == 0) {
      foundError = true;
      setLNameError('Please enter your last name');
    } else if (lName[0].toLowerCase() == lName[0]) {
      foundError = true;
      setLNameError('Please capitalize your name');
    } else {
      setLNameError('');
    }

    if (mName.length == 0 && middle == false) {
      foundError = true;
      setNameMError('Please enter your middle name');
    } else {
      setNameMError('');
    }

    if (prefixField.length == 0 && prefix == false) {
      foundError = true;
      setPrefixError('Please enter a prefix');
    } else {
      setPrefixError('');
    }

    if (suffixField.length == 0 && suffix == false) {
      foundError = true;
      setSuffixError('Please enter a suffix');
    } else {
      setSuffixError('');
    }

    if (email.length == 0) {
      foundError = true;
      setEmailError('Please enter your email');
    } else if (email.indexOf('@') == -1) {
      foundError = true;
      setEmailError('Provide a valid email');
    } else {
      setEmailError('');
    }

    if (zip.length != 5) {
      foundError = true;
      setZipError('Please enter a 5 digit zip code');
    } else {
      setZipError('');
    }

    if (check) {
      setCheckError('');
      console.log('check');
    } else {
      foundError = true;
      setCheckError('Please verify your zip code is correct');
      console.log(check);
    }

    if (foundError == true) {
      e.preventDefault();
      alert('Please fill in the required fields correctly');
    } else {
      alert("You've been entered into the giveaway!");
    }

  }

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label htmlFor="first-name">First Name: </label>
        <input
          type="text"
          id="first-name"
          value={fName}
          onChange={handleChange}
        />
        <p className="red">{fNameError}</p>
      </div>

      <div>
        <label htmlFor="last-name">Last Name: </label>
        <input
          type="text"
          id="last-Name"
          value={lName}
          onChange={handleChange}
        />
        <p className="red">{lNameError}</p>
      </div>

      <div>
        <p>Check to show additional name options:</p>
        <input
          type="checkbox"
          id="prefix"
          value={prefix}
          onChange={handleOptionChange}
        />
        <label htmlFor="prefix">Prefix</label>
        <input
          type="checkbox"
          id="suffix"
          value={suffix}
          onChange={handleOptionChange}
        />
        <label htmlFor="suffix">Suffix</label>
        <input
          type="checkbox"
          id="middle"
          value={middle}
          onChange={handleOptionChange}
        />
        <label htmlFor="middle">Middle Name</label>
      </div>

      <div className="prefix-box">
        <label htmlFor="prefix-field">Prefix: </label>
        <input
          type="text"
          id="prefix-field"
          value={prefixField}
          onChange={handleChange}
        />
        <p className="red">{prefixError}</p>
      </div>

      <div className="suffix-box">
        <label htmlFor="suffix-field">Suffix: </label>
        <input
          type="text"
          id="suffix-field"
          value={suffixField}
          onChange={handleChange}
        />
        <p className="red">{suffixError}</p>
      </div>

      <div className="middle-box">
        <label htmlFor="middle-name">Middle Name:</label>
        <input
          type="text"
          id="middle-name"
          value={mName}
          onChange={handleChange}
        />
        <p className="red">{mNameError}</p>
      </div>

      <div>
        <label htmlFor="email">Email: </label>
        <input type="text" id="email" value={email} onChange={handleChange} />
        <p className="red">{emailError}</p>
      </div>
      <div>
        <label htmlFor="zip">Zip Code: </label>
        <input type="text" id="zip" value={zip} onChange={handleChange} />
        <p className="red">{zipError}</p>
      </div>

      <div>
        <button onClick={verify}>Verify Details</button>
        <p className="red">{checkError}</p>
      </div>

      <div className="hide">
        <label htmlFor="city">
          The zip code you entered is in
          {' ' + city}. Check the box if this is correct.
        </label>
        <input
          type="checkbox"
          id="check"
          value={check}
          onChange={handleChange}
        />
        <p className="red">{checkError}</p>
      </div>
      <div>
        <button>Submit</button>
      </div>
    </form>
  );
}
