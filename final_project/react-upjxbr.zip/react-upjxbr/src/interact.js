import React from 'react';
import { useState } from 'react';
import $ from 'jquery';
// import BookList from './book.js';
// import Generator from './generator.js';

export default function Interact() {
  return (
    <div>
      
  );
}

function Generator(props) {
  const [title, setTitle] = useState('Harry Potter');
  const [ban, setBan] = useState(
    'Reason banned: DOC 309.05 (2)(b)(4) how to make alcohol'
  );
  const [result, setResult] = useState([]);
  const [src, setSrc] = useState(
    'https://m.media-amazon.com/images/I/51uvhT-uqbL.jpg'
  );
  const [author, setAuthor] = useState('JK Rowling');

  function newCover() {
    console.log('new Cover!');
    // print(console.log(props.pub);
    var search = props.pub.split(' ').join('+');
    var searchAuthor = props.author.split(' ').join('+');
    var searchUrl =
      'https://openlibrary.org/search.json?title=' +
      search +
      '&author=' +
      searchAuthor;
    console.log(searchUrl);
    $.ajax({
      url: searchUrl,
      dataType: 'json',
      success: function (data) {
        var newSrc =
          'https://covers.openlibrary.org/b/olid/' +
          data.docs[0].edition_key[0] +
          '.jpg';
        props.setSrc(newSrc);
      },
      error: function (error) {
        console.log(error);
        props.setSrc(
          'https://images-na.ssl-images-amazon.com/images/I/61AWtiaipKL._SLDPMOBCAROUSELAUTOCROP288221_MCnd_AC_SR462,693_.jpg'
        );
      },
    });
  }

  function newBook(e) {
    e.preventDefault();
    console.log('clicked!');
    $.ajax({
      url: 'https://banned-prison-books-api.onrender.com/api/v1/books/random',
      type: 'GET',
      dataType: 'json',
      contentType: 'application/json; charset=utf-8',
      headers: {
        'Access-Control-Allow-Origin': '*',
      },
      success: function (data) {
        console.log(data);
        // setResult(data.data);
        // setTitle(result.publication);
        // setAuthor(result.author);
        // setBan('Reason banned: ' + result.reason);
        // console.log('newbook!');
        // newCover();
      },
      error: function (error) {
        console.log(error);
      },
    });
  }

  return (
    <div className="box">
      <button onClick={newBook}>test things button</button>
      <div>
        <img src={props.src} alt={props.pub + 'cover'} />
      </div>
      <div className="boxinfo">
        <p className="bTitle">{props.pub}</p>
        <p className="author">{props.author}</p>
        <p className="ban">{ban}</p>
        <div className="iconbox">
          <div className="plus">
            <img
              onClick={newBook}
              src="https://cdn.iconscout.com/icon/free/png-256/free-plus-89-433616.png"
              alt="add button"
            />
          </div>
          <div className="refresh">
            <img
              src="https://cdn.iconscout.com/icon/free/png-256/free-refresh-454-450611.png"
              alt="refresh button"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function BookList(props) {
  // readingList.map((elt) => {
  return (
    <div>
      <img className="bookCover" src={props.src} alt={props.pub + ' cover'} />
      <p>{props.pub}</p>
      <button className="remove">Remove</button>
    </div>
  );
  // });
}
