import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import $ from 'jquery';
import Generator from './generator.js';
import Content from './content.js';
import Form from './form.js';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div className="header">
      <div className="nav">
        <a href="#main1">Profile</a>
      </div>
      <div className="nav">
        <a href="#main2">Content</a>
      </div>
      <div className="nav">
        <a href="#main3">Giveaway</a>
      </div>
    </div>
    <div>
      <div id="main1">
        <h1>Profile Generator</h1>
        <p>
          Whether you want to sign up for a social media app without caring what
          you post, get ideas for a unique username, or have a better profile
          picture than the default, having randomly generated profile
          information can be useful in many situations.
        </p>
        <p>
          According to the Security.org, 38% of Americans report having at least
          one of their passwords cracked or guessed. Having a randomly generated
          password is a great way to ensure your security. Use the two
          generators below to generate profile information, including a profile
          photo, and then images for your first post!
        </p>
        <p>
          IMPORTANT NOTE: Your first new set of profile information may take up to a
          minute to load. Unless an error button appears after hitting the new
          profile refresh, please wait for a minute before rehitting the refresh button or refreshing the page.
        </p>
        <Generator />
        <a href="#main2">
          <img
            className="down"
            src="https://cdn.iconscout.com/icon/free/png-256/free-down-arrow-1767499-1502567.png"
            alt="down arrow"
          />
        </a>
      </div>

      <div id="main2">
        <h2>Your first post</h2>
        <p>
          Use the refresh button to generate random images of adorable animals
          for your first post!
        </p>
        <Content />
        <a href="#main3">
          <img
            className="down"
            src="https://cdn.iconscout.com/icon/free/png-256/free-down-arrow-1767499-1502567.png"
            alt="down arrow"
          />
        </a>
      </div>
    </div>
    <div id="main3">
      <p>
        Enter your details to enter our givaways for a subscription to a
        password managing service of your choice!
      </p>
      <Form />
    </div>
    <div className="bar"></div>
  </React.StrictMode>
);
