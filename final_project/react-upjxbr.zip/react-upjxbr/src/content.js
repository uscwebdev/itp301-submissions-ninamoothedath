import React from 'react';
import { useState } from 'react';
import $ from 'jquery';

export default function Content() {
  const [dogSrc, setDogSrc] = useState(
    'https://images.dog.ceo/breeds/greyhound-italian/n02091032_561.jpg'
  );
  const [catSrc, setCatSrc] = useState(
    'https://cdn.shibe.online/cats/86f24761fdb4a1574082f1bb39441cfcf570dd73.jpg'
  );
  const [birdSrc, setBirdSrc] = useState('https://randomfox.ca/images/17.jpg');
  const [foxSrc, setFoxSrc] = useState(
    'https://cdn.shibe.online/birds/78feac0adbbbd397f21d822a95094dcd6b66a402.jpg'
  );
  // const[]

  function newContent(e) {
    e.preventDefault();
    console.log('clicked!');
    newDog();
    newCat();
    newBird();
    newFox();
  }

  function newDog() {
    console.log('dog');
    $.ajax({
      url: 'https://dog.ceo/api/breeds/image/random',
      dataType: 'json',
      success: function (data) {
        setDogSrc(data.message);
      },
      error: function (error) {
        console.log(error);
      },
    });
  }

  function newCat() {
    console.log('cat');
    $.ajax({
      url: 'https://shibe.online/api/cats',
      // dataType: 'json',
      success: function (data) {
        console.log(data[0]);
        setCatSrc(data[0]);
      },
      error: function (error) {
        console.log(error);
      },
    });
  }

  function newBird() {
    console.log('duck');
    $.ajax({
      url: 'https://shibe.online/api/birds',
      // dataType: 'json',
      success: function (data) {
        console.log(data[0]);
        setBirdSrc(data[0]);
      },
      error: function (error) {
        console.log(error);
      },
    });
  }

  function newFox() {
    console.log('fox');
    $.ajax({
      url: 'https://randomfox.ca/floof/',
      // dataType: 'json',
      success: function (data) {
        console.log(data.image);
        setFoxSrc(data.image);
      },
      error: function (error) {
        console.log(error);
      },
    });
  }

  return (
    <div className="box fr">
      <div className="content-pics">
        <p>Dog:</p>
        <img src={dogSrc} alt={'thumbnail'} />
      </div>
      <div className="content-pics">
        <p>Cat:</p>
        <img src={catSrc} alt={'thumbnail'} />
      </div>
      <div className="content-pics">
        <p>Fox:</p>
        <img src={foxSrc} alt={'thumbnail'} />
      </div>
      <div className="content-pics">
        <p>Bird:</p>
        <img src={birdSrc} alt={'thumbnail'} />
      </div>

      <div className="iconbox content-refresh">
        <div className="refresh">
          <img
            onClick={newContent}
            src="https://cdn.iconscout.com/icon/free/png-256/free-refresh-454-450611.png"
            alt="refresh button"
          />
        </div>
      </div>
    </div>
  );
}
