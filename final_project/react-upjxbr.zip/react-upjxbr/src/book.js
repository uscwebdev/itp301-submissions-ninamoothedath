import React from 'react';
import { useState } from 'react';
import $ from 'jquery';

export default function BookList() {
  //   readingList.map((elt) => {
  //     return (
  //       <div id={elt.id}>
  //         <img
  //           className="bookCover"
  //           src={cover}
  //           alt={elt.publication + ' cover'}
  //         />
  //         <p>{elt.publication}</p>
  //         <button className="remove">Remove</button>
  //       </div>
  //     );
  //   });

  return (
    <div>
      <img
        className="bookCover"
        src="https://m.media-amazon.com/images/I/51uvhT-uqbL.jpg"
        alt="bookcover"
      />
      <p>
        Description LOREM IPSUM Description LOREM IPSUM Description LOREM IPSUM
        Description LOREM IPSUM Description LOREM IPSUM Description LOREM IPSUM
        Description LOREM IPSUM Description LOREM IPSUM Description LOREM IPSUM{' '}
      </p>
      <button className="remove">Remove</button>
    </div>
  );
}
