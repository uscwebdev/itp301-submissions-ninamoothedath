import React from 'react';
import { useState } from 'react';

export default function Products() {
  const [subtotal, setSubtotal] = useState(0);

  function handleLess(price) {
    var price = parseInt(price);
    setSubtotal(subtotal - price);
    console.log(price);
  }

  function handleMore(price) {
    var price = parseInt(price);
    setSubtotal(subtotal + price);
    console.log(price);
  }

  return (
    <div className="prodBox">
      <Product
        src="https://www.aiany.org/wp-content/uploads/2019/08/New-York-City_Jorge-Lascar-1280x850.jpg"
        name="New York"
        price="3500"
        lessEvent={handleLess}
        moreEvent={handleMore}
      />
      <Product
        src="https://pix4free.org/assets/library/2021-01-12/originals/los_angeles_california_cityscape_downtown_offices.jpg"
        name="Los Angeles"
        price="1500"
        lessEvent={handleLess}
        moreEvent={handleMore}
      />
      <Product
        src="https://www.travelandleisure.com/thmb/xsZOdFFzSrZ2tEs0u6Rr-bN10Oo=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/houston-texas-HTXTG0221-7e22cd4db19f46d7820fa124e25d4d75.jpg"
        name="Houston"
        price="1000"
        lessEvent={handleLess}
        moreEvent={handleMore}
      />
      <Product
        src="https://upload.wikimedia.org/wikipedia/commons/b/b7/Chicago_cityscape_%285253757001%29.jpg"
        name="Chicago"
        price="2500"
        lessEvent={handleLess}
        moreEvent={handleMore}
      />
      <p>Subtotal: ${subtotal}</p>
    </div>
  );
}

function Product(prop) {
  const [count, setCount] = useState(0);

  function handleMinusClick() {
    if (count == 0) {
      console.log('0');
    } else {
      setCount(count - 1);
      prop.lessEvent(prop.price);
    }
  }

  function handlePlusClick() {
    setCount(count + 1);
    prop.moreEvent(prop.price);
  }

  return (
    <div className="product">
      <img src={prop.src} alt={prop.name + 'picture'} className="prodPic" />
      <p className="name">{prop.name + ' Apartment'}</p>
      <p className="price">{'$' + prop.price}</p>
      <div className="buttons">
        <button
          onClick={() => {
            handleMinusClick();
          }}
        >
          -
        </button>
        <p id="counter">{count}</p>
        <button
          onClick={() => {
            handlePlusClick();
          }}
        >
          +
        </button>
      </div>
    </div>
  );
}
