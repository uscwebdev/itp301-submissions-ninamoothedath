import React from 'react';
import { createRoot } from 'react-dom/client';
import Products from './Product.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div className="header">
      <h1>Apartment Shopper</h1>
    </div>
    <Products />
    <div className="footer">
      <p>Appartment Shopper&copy;</p>
    </div>
  </React.StrictMode>
);
