import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div className="main">
      <h1>Nina Moothedath</h1>

      <p>
        <a href="mailto:mootheda@usc.edu">mootheda@usc.edu</a>
      </p>

      <p id="blue">My favorite color: Blue!</p>

      <p>
        <a href="https://pointerpointer.com/">
          My favorite website: Pointer Pointer!
        </a>
      </p>

      <p>My favorite activity: Crochet!</p>
      <img
        src="https://www.sigonimacaroni.com/wp-content/uploads/2020/12/122130221_3657827890914907_7598048320064438940_n.jpg"
        alt="someone crocheting"
      />

      <p>My classes this semester:</p>
      <ul>
        <li>ITP 259</li>
        <li>ITP 304</li>
        <li>ITP 499</li>
        <li>JOUR 322</li>
        <li>JOUR 462</li>
      </ul>
    </div>
  </React.StrictMode>
);
