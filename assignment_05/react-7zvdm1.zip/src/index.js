import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div className="header">
      <h1>- Journalize -</h1>
    </div>

    <div className="text">
      <p>
        Welcome to Jouranlize, the collaborative jouranling platform you've been
        waiting for. Visit every day for a journaling prompt for you to complete
      </p>
      <p>
        It's your choice whether you want to journal your answers in a physical
        journal, privatley within your digital Journalize journal, or to your
        public Journalize page!
      </p>
      <p>
        You can find today's journaling music of the day{' '}
        <a href="https://www.youtube.com/watch?v=ZZUD25bZBI8">at this link</a>{' '}
        while you check out some of the responses to today's prompt, "What
        lifted your mood today?":
      </p>
    </div>

    <div className="imgBox">
      <img
        src="https://images.unsplash.com/photo-1604933762161-67313106146c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2940&q=80"
        alt="a person typing"
      />
      <img
        src="https://images.unsplash.com/photo-1488190211105-8b0e65b80b4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2940&q=80"
        alt="a person writing in a journal, birds eye view"
      />
    </div>

    <div className="responses">
      <div className="commentBox">
        <div>
          <img
            src="https://cdn4.iconfinder.com/data/icons/social-messaging-ui-color-squares-01/3/30-512.png"
            alt="profile picture"
            className="profile"
          />
          <p className="user">User20021</p>
          <p className="date">9/8/2023</p>
        </div>
        <div>
          <p class="post">
            Today I had one of my favorite foods! It was so comforting and I'm
            really glad I had it!
          </p>
        </div>
      </div>

      <div className="commentBox">
        <div>
          <img
            src="https://cdn4.iconfinder.com/data/icons/social-messaging-ui-color-squares-01/3/30-512.png"
            alt="profile picture"
            className="profile"
          />
          <p className="user">Janet_Rose</p>
          <p className="date">9/8/2023</p>
        </div>
        <div>
          <p class="post">
            I was in the store and heard a song I really like playing! It made
            me smile.
          </p>
        </div>
      </div>

      <div className="commentBox">
        <div>
          <img
            src="https://cdn4.iconfinder.com/data/icons/social-messaging-ui-color-squares-01/3/30-512.png"
            alt="profile picture"
            className="profile"
          />
          <p className="user">someone_out_there</p>
          <p className="date">9/8/2023</p>
        </div>
        <div>
          <p class="post">
            Someone told me that they thought my outfit looked nice! That was so
            thoughtful!
          </p>
        </div>
      </div>

      <div className="commentBox">
        <div>
          <img
            src="https://cdn4.iconfinder.com/data/icons/social-messaging-ui-color-squares-01/3/30-512.png"
            alt="profile picture"
            className="profile"
          />
          <p className="user">GreenGarnet</p>
          <p className="date">9/8/2023</p>
        </div>
        <div>
          <p class="post">
            I went to see a movie with some friends and it was super fun! We got
            boba afterwards :)
          </p>
        </div>
      </div>
    </div>
  </React.StrictMode>
);
