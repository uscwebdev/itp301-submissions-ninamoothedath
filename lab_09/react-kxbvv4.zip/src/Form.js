import React from 'react';
import { useState } from 'react';

export default function Form() {
  const [fullName, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [passwordConfirm, setPasswordConfirm] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [comments, setComments] = useState('');
  const [terms, setTerms] = useState(false);

  const [nameError, setNameError] = useState();
  const [passwordError, setPasswordError] = useState();
  const [passwordConfirmError, setPasswordConfirmError] = useState();
  const [contactError, setContactError] = useState();
  const [commentsError, setCommentsError] = useState();
  const [termsError, setTermsError] = useState();

  function handleChange(e) {
    var name = e.currentTarget.name;
    if (name == 'fullName') {
      setFullName(e.currentTarget.value);
    } else if (name == 'password') {
      setPassword(e.currentTarget.value);
    } else if (name == 'passwordConfirm') {
      setPasswordConfirm(e.currentTarget.value);
    } else if (name == 'email') {
      setEmail(e.currentTarget.value);
    } else if (name == 'phone') {
      setPhone(e.currentTarget.value);
    } else if (name == 'comments') {
      setComments(e.currentTarget.value);
    } else if (name == 'terms') {
      setTerms(!terms);
    }
  }

  function handleSubmit(e) {
    var foundError = false;

    if (fullName.length == 0) {
      foundError = true;
      setNameError('Name cannot be empty.');
      console.log(nameError);
    } else if (fullName.indexOf(' ') == -1) {
      foundError = true;
      setNameError('You must provide a full name.');
    } else {
      setNameError('');
    }

    if (password.length == 0) {
      foundError = true;
      setPasswordError('Password cannot be empty.');
    } else if (password.length < 5) {
      foundError = true;
      setPasswordError('Password must contain at least 5 characters.');
    } else if (
      password == password.toLowerCase() ||
      password == password.toUpperCase()
    ) {
      foundError = true;
      setPasswordError(
        'Password must contain uppercase and lowercase characters.'
      );
    } else {
      setPasswordError('');
    }

    if (passwordConfirm != password) {
      foundError = true;
      setPasswordConfirmError('Passwords do not match.');
    } else {
      setPasswordConfirmError('');
    }

    if (email.length == 0 && phone.length == 0) {
      foundError = true;
      setContactError('You must provide either email or phone');
    } else {
      setContactError('');
    }

    if (comments.length > 100) {
      foundError = true;
      setCommentsError('Comments cannot exceed 100 characters.');
    } else {
      setCommentsError('');
    }

    if (terms == false) {
      foundError = true;
      setTermsError('You must accept Terms & Conditions.');
    } else {
      setTermsError('');
    }

    if (foundError == true) {
      e.preventDefault();
      alert(
        nameError +
          '\n' +
          passwordError +
          '\n' +
          passwordConfirmError +
          '\n' +
          contactError +
          '\n' +
          commentsError +
          '\n' +
          termsError
      );
    } else {
      alert('The form was successfully submitted');
    }
  }

  return (
    <div className="container my-3">
      <div className="row">
        <div className="col-12">
          <form onSubmit={handleSubmit}>
            <div className="my-3 row">
              <label htmlFor="full-name" className="col-sm-2 col-form-label">
                Full Name: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Tommy Trojan"
                  id="full-name"
                  name="fullName"
                  value={fullName}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="password" className="col-sm-2 col-form-label">
                Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  name="password"
                  id="password"
                  value={password}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="my-3 row">
              <label
                htmlFor="password-confirm"
                className="col-sm-2 col-form-label"
              >
                Confirm Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password-confirm"
                  name="passwordConfirm"
                  value={passwordConfirm}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label">
                Provide One: <span className="text-danger">*</span>
              </label>
              <div className="col-10">
                <div className="row">
                  <label htmlFor="email" className="col-sm-2 col-form-label">
                    Email:
                  </label>
                  <div className="col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="ttrojan@usc.edu"
                      id="email"
                      name="email"
                      value={email}
                      onChange={handleChange}
                    />
                  </div>

                  <label
                    htmlFor="phone"
                    className="mt-sm-2 col-sm-2 col-form-label"
                  >
                    Phone:
                  </label>
                  <div className="mt-sm-2 col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="(123) 456-7890"
                      id="phone"
                      name="phone"
                      value={phone}
                      onChange={handleChange}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="comment" className="col-sm-2 col-form-label">
                Comments:
              </label>
              <div className="col-sm-10">
                <textarea
                  className="form-control"
                  id="comment"
                  name="comments"
                  value={comments}
                  onChange={handleChange}
                ></textarea>

                <small id="comment-count" className="form-text text-right">
                  {comments.length} / 100
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label"></label>
              <div className="col-sm-10">
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="terms"
                    value="terms"
                    name="terms"
                    checked={terms}
                    onChange={handleChange}
                  />
                  <label className="form-check-label" htmlFor="terms">
                    I accept Terms & Conditions.
                    <span className="text-danger">*</span>
                  </label>
                </div>
              </div>
            </div>
            <div className="my-3 row">
              <div className="col-sm-10">
                <button type="submit" className="btn btn-primary">
                  Register
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
